import collections, re

pats=[]
pats.append( re.compile(r"(\w* ){0,4}((sort)|(type)|(kind))") )
	


text="what kind of conatiner"
text1="what are you and kind of the type we contain" 
text2="what are you and we kind of the type we i contain"
text4="what are you and kind of the type we container" 
text5="what  kind of the type we contain"
text6="what are you and we sorting"


for reg in pats:

	if(re.match(reg,text)):
		print("matched text\n")

	if(re.match(reg,text1)):
		print("matched text1\n")
	if(re.match(reg,text2)):
		print("matched text2\n")
	if(re.match(reg,text4)):
		print("matched text4\n")
	if(re.match(reg,text5)):
		print("matched text5\n")
	if(re.match(reg,text6)):
		print("matched text6\n")
